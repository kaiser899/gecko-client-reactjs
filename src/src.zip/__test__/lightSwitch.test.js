import switchPosition from "../lightSwitch";

Date.now = jest.fn(() => new Date(Date.UTC(2017, 1, 14, 17, 55)).valueOf());

let testDate = new Date(Date.now());
test("testBattery with " + testDate.getUTCHours(), () => {
  expect(switchPosition(testDate)).toBe("APRINS");
});

//testDate = Date.now();
